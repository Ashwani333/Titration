AIM: To determine the strength of potassium permanganate by titrating it against the standard solution of 0.1M oxalic acid.
