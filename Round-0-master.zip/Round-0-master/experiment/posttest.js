
const myQuestions = [

    {

      question: "1.Titration is used to find the strength of ....... solution by using known solution?",

      answers: {

        a: " Liquid Solution",

        b: " Fluid Solution",

        c: " Buffer solution",

        d: " Unknown Solution ",

      },

      correctAnswer: "d"

    },

    {

      question: "2.KMnO4 is ........?",

      answers: {

        a: " Acid",

        b: " Base",
        
        c: " Self Indicator",
          
        d: " None Of These"
      },
        
        



      correctAnswer: "c"

    },

    {

      question: "3.What is the formula of oxalic acid ? ",

      answers: {

        a: "HCOOH",

        b: "CH3COOH ",

        c: "C2H5OH",

        d: " C2H2O4 "

      },

      correctAnswer: "d"

    },

   

  ];

