## This file contains all the codes related to Simulator
