<svg
   xmlns:dc="http://purl.org/dc/elements/1.1/"
   xmlns:cc="http://creativecommons.org/ns#"
   xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
   xmlns:svg="http://www.w3.org/2000/svg"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   width="210mm"
   height="297mm"
   viewBox="0 0 210 297"
   version="1.1"
   id="svg8"
   inkscape:version="0.92.4 (5da689c313, 2019-01-14)"
   sodipodi:docname="flowchart.svg">
  <defs
     id="defs2" />
  <sodipodi:namedview
     id="base"
     pagecolor="#ffffff"
     bordercolor="#666666"
     borderopacity="1.0"
     inkscape:pageopacity="0.0"
     inkscape:pageshadow="2"
     inkscape:zoom="0.98994949"
     inkscape:cx="340.8027"
     inkscape:cy="601.5516"
     inkscape:document-units="mm"
     inkscape:current-layer="layer1"
     showgrid="false"
     inkscape:window-width="1366"
     inkscape:window-height="745"
     inkscape:window-x="-8"
     inkscape:window-y="-8"
     inkscape:window-maximized="1" />
  <metadata
     id="metadata5">
    <rdf:RDF>
      <cc:Work
         rdf:about="">
        <dc:format>image/svg+xml</dc:format>
        <dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
        <dc:title></dc:title>
      </cc:Work>
    </rdf:RDF>
  </metadata>
  <g
     inkscape:label="Layer 1"
     inkscape:groupmode="layer"
     id="layer1">
    <rect
       style="fill:#ff5555;stroke:#e4ed10;stroke-width:0.26458332;stroke-opacity:0.94974874"
       id="rect4569"
       width="93.009796"
       height="20.312483"
       x="56.126598"
       y="14.496109" />
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:4.93888855px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458332"
       x="60.670181"
       y="20.643307"
       id="text4573"><tspan
         sodipodi:role="line"
         id="tspan4571"
         x="60.670181"
         y="20.643307"
         style="stroke-width:0.26458332">Prepare 0.1N Standard Solution</tspan><tspan
         sodipodi:role="line"
         x="60.670181"
         y="26.816917"
         style="stroke-width:0.26458332"
         id="tspan4575">              Of Oxalic Acid</tspan></text>
    <rect
       style="fill:#ff5555;stroke:#e4ed10;stroke-width:0.26458332;stroke-opacity:0.94974874"
       id="rect4579"
       width="6.4144688"
       height="16.83798"
       x="99.156998"
       y="34.808594" />
    <rect
       style="fill:#ff5555;stroke:#e4ed10;stroke-width:0.28836033;stroke-opacity:0.94974874"
       id="rect4581"
       width="90.046051"
       height="18.41782"
       x="57.474838"
       y="50.054848" />
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:4.93888855px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458332"
       x="63.610146"
       y="55.121078"
       id="text4585"><tspan
         sodipodi:role="line"
         id="tspan4583"
         x="63.610146"
         y="55.121078"
         style="stroke-width:0.26458332">     10ml of 0.1N Oxalic Acid</tspan><tspan
         sodipodi:role="line"
         x="63.610146"
         y="61.294689"
         style="stroke-width:0.26458332"
         id="tspan4587">                     +</tspan><tspan
         sodipodi:role="line"
         x="63.610146"
         y="67.4683"
         style="stroke-width:0.26458332"
         id="tspan4589">            sulphuric acid</tspan></text>
    <rect
       style="fill:#ff5555;stroke:#e4ed10;stroke-width:0.26458332;stroke-opacity:0.94974874"
       id="rect4591"
       width="5.0781207"
       height="16.036171"
       x="100.49334"
       y="68.217285" />
    <ellipse
       style="fill:#ff5555;stroke:#e4ed10;stroke-width:0.26458332;stroke-opacity:0.94974874"
       id="path4597"
       cx="103.70058"
       cy="89.197937"
       rx="18.708866"
       ry="4.9444861" />
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:4.93888855px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458332"
       x="96.751572"
       y="91.175606"
       id="text4601"><tspan
         sodipodi:role="line"
         id="tspan4599"
         x="96.751572"
         y="91.175606"
         style="stroke-width:0.26458332">Heat</tspan></text>
    <rect
       style="fill:#ff5555;stroke:#e4ed10;stroke-width:0.36900401;stroke-opacity:0.94974874"
       id="rect4603"
       width="4.1718917"
       height="118.83052"
       x="101.8819"
       y="94.194633" />
    <rect
       style="fill:#ff5555;stroke:#e4ed10;stroke-width:0.2240092;stroke-opacity:0.94974874"
       id="rect4605"
       width="80.755966"
       height="13.40405"
       x="62.0131"
       y="105.01036" />
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:4.93888855px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458332"
       x="63.610146"
       y="112.85129"
       id="text4609"><tspan
         sodipodi:role="line"
         id="tspan4607"
         x="63.610146"
         y="112.85129"
         style="stroke-width:0.26458332">        Note Initial Reading</tspan></text>
    <rect
       style="fill:#ff5555;stroke:#e4ed10;stroke-width:0.26458332;stroke-opacity:0.94974874"
       id="rect4611"
       width="78.309975"
       height="10.690781"
       x="64.679222"
       y="130.75835" />
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:4.93888855px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458332"
       x="71.628235"
       y="136.63828"
       id="text4615"><tspan
         sodipodi:role="line"
         id="tspan4613"
         x="71.628235"
         y="136.63828"
         style="stroke-width:0.26458332">      Titrate the solution</tspan></text>
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:4.93888855px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458332"
       x="67.886459"
       y="135.03467"
       id="text4619"><tspan
         sodipodi:role="line"
         id="tspan4617"
         x="67.886459"
         y="135.03467"
         style="stroke-width:0.26458332">   </tspan></text>
    <rect
       style="fill:#ff5555;stroke:#e4ed10;stroke-width:0.26458332;stroke-opacity:0.94974874"
       id="rect4621"
       width="80.180862"
       height="20.312483"
       x="63.904274"
       y="153.49777" />
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:4.93888855px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458332"
       x="66.282845"
       y="159.89072"
       id="text4625"><tspan
         sodipodi:role="line"
         id="tspan4623"
         x="66.282845"
         y="159.89072"
         style="stroke-width:0.26458332">    Color changes from Purple </tspan><tspan
         sodipodi:role="line"
         x="66.282845"
         y="166.06433"
         style="stroke-width:0.26458332"
         id="tspan4627">                 to Pink</tspan></text>
    <rect
       style="fill:#ff5555;stroke:#e4ed10;stroke-width:0.00192649;stroke-opacity:0.94974874"
       id="rect4629"
       width="3.4698913"
       height="0.00075962878"
       x="102.76745"
       y="-172.05188"
       transform="scale(1,-1)" />
    <rect
       style="fill:#ff5555;stroke:#e4ed10;stroke-width:0.30891758;stroke-opacity:0.94974874"
       id="rect4631"
       width="79.601982"
       height="17.862724"
       x="63.418758"
       y="209.15872" />
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:4.93888855px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458332"
       x="70.532295"
       y="216.82281"
       id="text4635"><tspan
         sodipodi:role="line"
         id="tspan4633"
         x="70.532295"
         y="216.82281"
         style="stroke-width:0.26458332">Repeat the titration until</tspan><tspan
         sodipodi:role="line"
         x="70.532295"
         y="222.99643"
         style="stroke-width:0.26458332"
         id="tspan4637">concordant values obtained</tspan></text>
    <rect
       style="fill:#ff5555;stroke:#e4ed10;stroke-width:0.30891758;stroke-opacity:0.94974874"
       id="rect4631-3"
       width="79.601982"
       height="17.862724"
       x="63.245541"
       y="182.97253" />
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:4.93888855px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458332"
       x="73.963829"
       y="192.7326"
       id="text4656"><tspan
         sodipodi:role="line"
         id="tspan4654"
         x="73.963829"
         y="192.7326"
         style="stroke-width:0.26458332">Note The Final Reading</tspan></text>
  </g>
</svg>

