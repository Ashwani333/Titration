## TITRATION

<br>

<b>Discipline | <b>Applied science And Humanities.
:--|:--|
<b> Lab. | <b>chemistry lab. 
<b> Experiment|     <b> Titration .



<h5> About the Experiment : </h5>
To study the strenghth of potassuium permanganate by titrating it against the standard solution of 0.1M oxalic acid.

<b>Name of Developer | <b> Dr. Shailendra Badal
:--|:--|
<b> Institute | <b> Rajkiya Engineering college,banda.
<b> Email id|     <b> badal70@rediffgmail.com
<b> Department | Applied science And Humanities

#### Contributors List

SrNo | Name | Faculty or Student | Department| Institute | Email id
:--|:--|:--|:--|:--|:--|
1 | Dr. Shailendra Badal| Faculty | |  Rajkiya Engineering College,Banda |badal70@rediffmail.com 
2 | Mr. Ashwani Gupta| Student | Information Technology|Rajkiya Engineering College,Banda  |ashwanigpt13@gmail.com
3 | Mr Vivek Kumar Dubey| Student |  Information Technology | Rajkiya Engineering College,Banda |vkd98765@gmail.com
4 | Sagun Singh  | Student |   Electrical Engineering | Rajkiya Engineering College,Banda |sagun13march@gmail.com
5 | Yaminee Devi | Student |  Electrical Engineering | Rajkiya Engineering College,Banda |yamineedevi120@gmail.com


<br>

