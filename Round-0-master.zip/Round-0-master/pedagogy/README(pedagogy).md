Pedagogy (Round 1)


Experiment:Titration.

Discipline	Applied Science And Humanities.
Lab	Chemistry Lab.
Experiment	To study the strenghth of potassuium permanganate by titrating it against the standard solution of 0.1M oxalic acid
.
[1. Focus Area](#LO)
[2. Learning Objectives ](#LO)
[4. Task & Assessment Questions](#AQ)
[5. Simulator Interactions](#SI)

1. Focus Area : Experimentation and Data Analysis
The students know the concept of titration and they will learn how to determine its strength,they will come to know how to determine the strenght of unknown solution titrating with known solution of oxalic acid.


↥ back to top


2. Learning Objectives and Cognitive Level
to determine the strenghth of potassuium permanganate by titrating it against the standard solution of 0.1M oxalic acid



↥ back to top


3. Task & Assessment Questions:
Read the theory and comprehend the concepts related to the experiment.

The quizes are provided that will judge and inhance the skills of the Student. Each question is relevent to the experiment and just ment to increase the understanding of experiment and their concept.


↥ back to top


4. Simulator Interactions:

Sr.No	What students will do?	What Simulator will do ?	Purpose of the task
1.	Student will click on Simulation tab	Simulator will ask for N1,V1,V2 and will give N2 ,and total power	This will test give the result of the experiment
2.	Student will click on Simulation tab	This will test the understandindg of experiment of student
